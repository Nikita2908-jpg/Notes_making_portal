document.addEventListener('DOMContentLoaded', () => {
    const usernameInput = document.getElementById('username');
    const saveButton = document.querySelector('.save-btn');
    const notesContainer = document.querySelector('.notes-container .input-box');
    const feedbackMessage = document.querySelector('.feedback-message');

    let username = localStorage.getItem('username');
    if (!username) {
        username = prompt("Enter your username:");
        if (username) {
            localStorage.setItem('username', username);
        }
    }
    saveButton.addEventListener('click', () => {
      //  const username = usernameInput.value.trim();
        const noteContent = notesContainer.innerText.trim();
        if (!username) {
            showFeedbackMessage("Username is not set. Please reload the page to set your username.", "error");
            return;
        }

        if (noteContent === "") {
            showFeedbackMessage("Please enter some content for the note before saving.", "error");
            return;
        }

        // Updated noteData structure to include user object with username
        const noteData = {
            content: noteContent,
            user: {
                username: username
            }
        };

        saveNoteToDatabase(noteData);
    });
});

function saveNoteToDatabase(noteData) {
    fetch('http://localhost:8080/notes/create', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(noteData)
    })
    .then(response => {
        if (!response.ok) {
            return response.text().then(text => {
                throw new Error(`HTTP error! status: ${response.status}, Message: ${text}`);
            });
        }
        return response.json();
    })
    .then(data => {
        showFeedbackMessage("Note saved successfully!", "success");
        document.querySelector('.notes-container .input-box').innerText = ''; 
    })
    .catch(error => {
        console.error('Error fetching JSON:', error);
        showFeedbackMessage(`Error saving note: ${error.message}`, "error");
    });
}

function showFeedbackMessage(message, type) {
    const feedbackMessage = document.querySelector('.feedback-message');
    feedbackMessage.textContent = message;

    if (type === "success") {
        feedbackMessage.classList.add('success');
        feedbackMessage.classList.remove('error');
    } else {
        feedbackMessage.classList.add('error');
        feedbackMessage.classList.remove('success');
    }

    feedbackMessage.style.display = 'block';

    setTimeout(() => {
        feedbackMessage.style.display = 'none';
    }, 3000);
}
 // Adding event listener to the logout button
 document.getElementById('logoutButton').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent the default link behavior
    
    // Clear any session or user-related data (like username, token, etc.)
    localStorage.removeItem('username'); // Clear the username or any session data
    
    // Redirect the user to the register page (or login page if preferred)
    window.location.href = 'register.html'; // Replace with your actual register page URL
});