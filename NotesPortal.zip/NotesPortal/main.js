// const form = document.getElementById('form');
// const openform = document.getElementById('openform');
// const openform1 = document.getElementById('openform1');
// const opennote = document.getElementById('opennote');

// openform.addEventListener('click', (event) => {
//     event.preventDefault();
//     // form.style.display = 'block';
//     // document.body.style.backdropFilter = 'blur(20px)';
// });
// openform1.addEventListener('click', (event) => {
//     event.preventDefault();
//     // form.style.display = 'block'; // Or maybe a different form?
//     // document.body.style.backdropFilter = 'blur(20px)';
// });

// document.addEventListener('DOMContentLoaded', () => {
//     const opennote = document.getElementById('opennote');
//     const isLoggedIn = localStorage.getItem('userLoggedIn') === 'true';

//     opennote.addEventListener('click', (event) => {
//         event.preventDefault();
//         if (isLoggedIn) {
//             window.location.href = 'createNote.html';
//         } else {
//             alert('Please log in to create a note.');
//         }
//     });
// });


// document.addEventListener('DOMContentLoaded', () => {
//     const form = document.getElementById('form');
//     const form1 = document.getElementById('form1');
//     const form2 = document.getElementById('form2');
//     const openform = document.getElementById('openform');
//     const openform1 = document.getElementById('openform1');
//     const opennote = document.getElementById('opennote');

//     openform.addEventListener('click', (event) => {
//         event.preventDefault();
//         form1.style.display = 'block';
//         document.body.style.backdropFilter = 'blur(20px)';
//     });

//     openform1.addEventListener('click', (event) => {
//         event.preventDefault();
//         form.style.display = 'block';
//         document.body.style.backdropFilter = 'blur(20px)';
//     });

//     const isLoggedIn = localStorage.getItem('userLoggedIn') === 'true';

//     opennote.addEventListener('click', (event) => {
//         event.preventDefault();
//         if (isLoggedIn) {
//             window.location.href = 'createNote.html';
//         } else {
//             alert('Please log in to create a note.');
//         }
//     });
// });