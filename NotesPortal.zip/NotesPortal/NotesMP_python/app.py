# from flask import Flask, request, jsonify
# from flask_cors import CORS
# from models import db, User, Note

# app = Flask(__name__)
# CORS(app)

# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///instance/notes.db'
# app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# db.init_app(app)

# with app.app_context():
#     db.create_all()

# @app.route('/api/users/register', methods=['POST'])
# def register():
#     data = request.json
#     if User.query.filter_by(username=data['username']).first():
#         return "Username already exists", 400
#     user = User(username=data['username'], password=data['password'])
#     db.session.add(user)
#     db.session.commit()
#     return "Registration successful", 200

# @app.route('/api/users/login', methods=['POST'])
# def login():
#     data = request.json
#     user = User.query.filter_by(username=data['username'], password=data['password']).first()
#     if user:
#         return "Login successful", 200
#     return "Invalid credentials", 401

# @app.route('/notes/create', methods=['POST'])
# def create_note():
#     data = request.json
#     user = User.query.filter_by(username=data['user']['username']).first()
#     if not user:
#         return "User not found", 404
#     note = Note(title=data['title'], content=data['content'], user=user)
#     db.session.add(note)
#     db.session.commit()
#     return jsonify({'id': note.id, 'title': note.title, 'content': note.content}), 201

# @app.route('/notes/user/<username>', methods=['GET'])
# def get_notes(username):
#     user = User.query.filter_by(username=username).first()
#     if not user:
#         return "User not found", 404
#     notes = Note.query.filter_by(user=user).all()
#     return jsonify([
#         {'id': n.id, 'title': n.title, 'content': n.content}
#         for n in notes
#     ])

# @app.route('/notes/<int:note_id>', methods=['DELETE'])
# def delete_note(note_id):
#     note = Note.query.get(note_id)
#     if not note:
#         return "Note not found", 404
#     db.session.delete(note)
#     db.session.commit()
#     return "Note deleted", 200

# if __name__ == '__main__':
#     app.run(debug=True, port=8080)

from flask import Flask, request, jsonify
from flask_cors import CORS
from models import db, User, Note
import os

app = Flask(__name__)
CORS(app)

# Ensure instance folder exists
os.makedirs('instance', exist_ok=True)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///instance/notes.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# Create tables
with app.app_context():
    db.create_all()